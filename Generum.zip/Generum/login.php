<?php
session_start();
include "db.php"; // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);

        // Password verify karo (agar encrypted hai)
        if (password_verify($password, $user['password'])) {
            $_SESSION['username'] = $user['name']; // Name store karo session me
            header("Location: index.php"); // Redirect home page pe
            exit();
        } else {
            echo "Invalid username or password!";
        }
    } else {
        echo "Invalid username or password!";
    }
}
?>
