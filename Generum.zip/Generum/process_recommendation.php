<?php 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $gender = $_POST['gender'];
    $skin_color = $_POST['skin_color'];
    $hair_color = $_POST['hair_color'];
    $height = $_POST['height'];
    $body_size = $_POST['body_size'];

    // ड्रेस रिकमेंडेशन लॉजिक
    $recommendation = "";
    $image = "";

    if ($gender == "male") {
        if ($skin_color == "fair") {
            $recommendation = "White Shirt with Black Trousers";
            $image = "image/male_white_black.jpg"; // यहाँ path ठीक किया
        } elseif ($skin_color == "medium") {
            $recommendation = "Blue Denim Shirt with Chinos";
            $image = "image/male_blue_chinos.jpg";
        } else {
            $recommendation = "Dark Brown Blazer with Black Jeans";
            $image = "image/male_brown_black.jpg";
        }
    } else { // Female Recommendations
        if ($skin_color == "fair") {
            $recommendation = "Red Floral Dress";
            $image = "image/female_red_dress.jpg";
        } elseif ($skin_color == "medium") {
            $recommendation = "Peach Maxi Dress";
            $image = "image/female_peach_maxi.jpg";
        } else {
            $recommendation = "Golden Saree";
            $image = "image/female_golden_saree.jpg";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dress Recommendation</title>
    <style>

body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            padding: 20px;
        }

        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            margin: auto;
        }

        h2 {
            color: #333;
            margin-bottom: 10px;
        }

        p {
            font-size: 18px;
            font-weight: bold;
            color: #555;
        }

        img {
            width: 100%;
            max-width: 300px;
            height: auto;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.3);
        }

        a {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            text-decoration: none;
            color: white;
            background-color: #007bff;
            border-radius: 5px;
            transition: 0.3s;
        }

        a:hover {
            background-color: #0056b3;
        }
    </style>
        </style>

</head>
<body>

<div class="container text-center">
    <h2>Your Recommended Dress</h2>
    <p><strong><?php echo $recommendation; ?></strong></p>
    <img src="<?php echo $image; ?>" alt="Recommended Dress" style="width:300px; height:auto; border-radius:10px;">
    <br><br>
    <a href="recommendation.php">Go Back</a>
</div>

</body>
</html>
